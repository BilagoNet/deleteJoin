import asyncio

from json import loads

from concurrent.futures import ThreadPoolExecutor
from functools import wraps, partial
from typing import Optional

from contextlib import suppress
import urllib3

from aiohttp import ClientSession, BasicAuth

from loader import validate_url, vote_url, headers

urllib3.disable_warnings()


class to_async:

    def __init__(self, *, executor: Optional[ThreadPoolExecutor] = None):
        self.executor = executor

    def __call__(self, blocking):
        @wraps(blocking)
        async def wrapper(*args, **kwargs):
            loop = asyncio.get_event_loop()
            if not self.executor:
                self.executor = ThreadPoolExecutor()

            func = partial(blocking, *args, **kwargs)

            return await loop.run_in_executor(self.executor, func)

        return wrapper


base_url = "https://reposu.org/"

proxy_auth = BasicAuth("user-lu2320441-region-uz-sessid-uz4peymmqweyvi3dvu-sesstime-1", 'Oyatillo99')


async def get_proxy():
    get_proxy_url = "https://tq.lunaproxy.com/getflowip?neek=1026859&num=1&type=1&sep=6&regions=uz&ip_si=1&level=1&sb="
    async with ClientSession() as session:
        async with session.get(get_proxy_url) as r:
            data = await r.text()
    return data


async def get_result(response_id):
    async with ClientSession() as session:
        async with session.get(base_url+response_id) as r:
            data = await r.json()
    return data.get("response").get('response').get("data")


async def get_numbers(app_id):
    async with ClientSession() as session:
        url = "https://ttsave.uz/getList.php"
        params = {'application_id': app_id}
        async with session.get(url, headers={'Content-Type': 'application/json'}, params=params) as response:
            data = await response.text()
    return loads(data)


async def checkSite(app_id):
    async with ClientSession() as session:
        with suppress(Exception):
            async with session.get(f"https://admin.openbudget.uz/api/v1/application/{app_id}/") as _:
                pass
            return True
        return False


async def getCaptcha(ip):
    async with ClientSession() as session:
        url = 'https://openbudget.uz/api/v2/vote/mvc/captcha/1c2d5d67-0a10-452a-b6bb-c324d246f40e'
        try:
            async with session.get(url, headers=headers) as response:
                captchain = await response.text()

                response_code = response.status
            if response_code == 200:
                return captchain
            else:
                print(await response.text())
                return False
        except Exception as e:
            print(e)
            return False


async def validate_phone(vote_payload, ip):
    async with ClientSession() as session:
        headers = {
                'Origin': 'https://openbudget.uz',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
                'Cookie': 'ADRUM_BT1=R:91|i:7753|e:68; ADRUM_BTa=R:91|g:7a67198f-736c-4e57-baae-341894f3bf48|n:customer1_9c28b63e-99cb-4969-b91e-d0d7809dc215; OB-SESSION=64edddef629dcf60c8cead49; SameSite=None; route=f1d639df3365f84857f1ac304886ad41'
            }
        
        async with session.post(validate_url, headers=headers, data=vote_payload) as res:
            if res.status not in [200]:
                print(ip, res.status, await res.text())
            else:
                print(res.cookies)
            if res.status in [429, 500]:
                data = await validate_phone(vote_payload, ip)
                return data
            try:
                data = await res.text()
            except Exception as e:
                print(await res.text(), 4)
                data = {'detail': e}
            return data

# send request
async def reCaptchaV3(ip):
    async with ClientSession() as session:
        async with session.get(f"http://localhost:8081?ip={ip}") as response:
            data = await response.json()
            return data.get('token')

async def send_vote(payload, ip):
    
    reCaptcha_response = await reCaptchaV3(ip)
    
    payload['grToken'] = reCaptcha_response
    
    async with ClientSession() as session:
        
        async with session.post(vote_url, data=payload, headers=headers) as response:
            with open('verfy.html', 'w+') as f:
                data = await response.text()
                f.write(data)
                
            if response.status in [429, 500, 403]:
                data = await send_vote(payload, ip)
                return data
            else:
                data = await response.text()
            return data
