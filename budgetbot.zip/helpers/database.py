# -*- coding: utf-8 -*-

from typing import Optional

from asyncio import get_event_loop

from pymysql import err as mysql_errors
from contextlib import suppress

from aiomysql import Pool, create_pool
from aiomysql.cursors import DictCursor

from aiohttp import ClientSession, BasicAuth


class MySQLStorage:
    def __init__(self, database: str, host: str = 'localhost', port: int = 3306, user: str = 'root',
                 password=None, pool_create: bool = True):
        self.pool: Optional[Pool] = None
        self.host: str = host
        self.port: int = port
        self.user: str = user
        self.password: str = password
        self.database = database

        if pool_create:
            loop = get_event_loop()
            loop.run_until_complete(self.acquire_pool())
        super().__init__()

    def __del__(self):
        self.pool.close()

    async def acquire_pool(self):
        if isinstance(self.pool, Pool):
            with suppress(Exception):
                self.pool.close()

        self.pool = await create_pool(host=self.host, port=self.port, user=self.user,
                                      password=self.password, db=self.database)

    @staticmethod
    def _verify_args(args):
        if args is None:
            args = tuple()
        if not isinstance(args, (tuple, dict)):
            args = (args,)
        return args

    async def apply(self, query: str, args=None) -> int:
        args = self._verify_args(args)
        async with self.pool.acquire() as conn:
            async with conn.cursor(DictCursor) as cursor:
                try:
                    await cursor.execute(query, args)
                    await conn.commit()
                    return True
                except mysql_errors.Error as e:
                    await conn.rollback()
                    return False

    async def select(self, query: str, args=None):
        args = self._verify_args(args)
        async with self.pool.acquire() as conn:
            async with conn.cursor(DictCursor) as cursor:
                try:
                    await cursor.execute(query, args)
                    await conn.commit()
                    while True:
                        item = await cursor.fetchone()
                        if item:
                            yield item
                        else:
                            break
                except mysql_errors.Error as e:
                    print(e, "salom")
                    pass

    async def get(self, query: str, args=None,
                  fetch_all: bool = False):
        args = self._verify_args(args)
        async with self.pool.acquire() as conn:
            async with conn.cursor(DictCursor) as cursor:
                try:
                    await cursor.execute(query, args)
                    await conn.commit()

                    if fetch_all:
                        return await cursor.fetchall()
                    else:
                        result = await cursor.fetchone()
                        return result if result else dict()
                except mysql_errors.Error as e:
                    print(e)
                    await conn.rollback()
                    return False

    async def check(self, query: str, args=None) -> int:
        args = self._verify_args(args)
        async with self.pool.acquire() as conn:
            async with conn.cursor(DictCursor) as cursor:
                try:
                    await cursor.execute(query, args)
                    await conn.commit()
                    return cursor.rowcount
                except mysql_errors.Error:
                    await conn.rollback()
                    return 0

    async def exist_user(self, chat_id):
        return bool(await self.check("select 1 from users where chat_id=%s", chat_id))

    async def check_number(self, phone):
        exist_registry = bool(await self.check("select 1 from registred_numbers where number=%s", phone))
        return exist_registry

    async def insert_registred_number(self, number):
        return await self.apply("""INSERT INTO registred_numbers (number) VALUES (%s)""", number)

    async def get_numbers_count(self):
        async with ClientSession() as session:
            app_id = await self.getApplicationId()
            async with session.get(
                    f"https://openbudget.uz/api/v2/info/initiative/count/{app_id}/",
                    headers={
                        'Accept': 'application/json, text/plain, */*',
                        "Accept-Encoding": "gzip, deflate, br",
                        "Accept-Language": "uz-UZ,uz;q=0.9,en-US;q=0.8,en;q=0.7",
                        "Connection": "keep-alive"
                    }) as res:
                try:
                    data = await res.json()
                except:
                    return await self.get_numbers_count()
        return data.get("count", 0)

    async def insert_user(self, user_id):
        return await self.apply("""INSERT INTO users (chat_id, is_active) VALUES (%s, 1)""", user_id)

    async def updateActive(self, chat_id, is_active):
        await self.apply("""UPDATE users SET is_active = %s WHERE chat_id = %s""", (is_active, chat_id))

    async def get_users(self):
        return self.select("""SELECT chat_id FROM users""")

    async def statistica(self):
        """Get users and numbers count"""
        referall = await self.referallMoney()
        withdraws = await self.getWithdraws() or 0
        users = await self.get("SELECT COUNT(*) as users, COUNT(is_active) as aktiv FROM users")
        numbers = await self.get("SELECT COUNT(*) as numbers FROM numbers")
        text = f"""Jami summa: {referall + withdraws}
Nomer summa: {withdraws}
Referall summa: {referall}
Nomer soni: {numbers.get('numbers', 0)}
Saytdan ro'yxatga o'tgan raqamlar: {await self.get_numbers_count()}
Userlar: {users.get('users', 0)}
Aktiv userlar: {users.get('aktiv', 0)}"""
        return text

    async def static(self):
        """Get users and numbers count"""
        referall = await self.referallMoney()
        withdraws = await self.getWithdraws() or 0
        users = await self.get("SELECT COUNT(*) as users, COUNT(is_active) as aktiv FROM users")
        numbers = await self.get("SELECT COUNT(*) as numbers FROM numbers")
        text = f"""
Userlar: {users.get('users', 0)}"""
        return text

    async def getApplicationId(self):
        raw = await self.get("SELECT application_id FROM panel")
        return raw.get("application_id")

    async def getCountsId(self, app_id):
        raw = await self.get("SELECT count(*) as counts FROM numbers where app_id=%s", (app_id))
        return raw.get('counts', 0)

    async def getReferallMoney(self):
        raw = await self.get("SELECT referall FROM panel")
        return raw.get("referall")

    async def getMinimalMoney(self):
        raw = await self.get("SELECT minimal FROM panel")
        return raw.get("minimal")

    async def getBalance(self, chat_id):
        raw = await self.get("SELECT balance FROM users where chat_id = %s", chat_id)
        return raw.get("balance")

    async def getMoney(self):
        raw = await self.get("SELECT money FROM panel")
        return raw.get("money")

    async def upBalance(self, chat_id):
        money = await self.getMoney()
        updated = await self.apply("UPDATE users SET `balance` = `balance` + %s WHERE chat_id = %s", (money, chat_id))
        return money if updated else False

    async def insert_number(self, chat_id, number):
        app_id = await self.getApplicationId()
        return await self.apply("""INSERT INTO numbers (chat_id, number, app_id) VALUES (%s, %s, %s)""",
                                (chat_id, number, app_id))

    async def change_money(self, money):
        await self.apply("""UPDATE panel SET money = %s""", money)

    async def downBalance(self, chat_id, summa):
        await self.apply("UPDATE users SET `balance` = `balance` - %s WHERE chat_id = %s", (summa, chat_id))
        # await self.apply("UPDATE withdraws SET `money` = `money` + %s", summa)

    async def upBonus(self, chat_id):
        summa = await self.getReferallMoney()
        updated = await self.apply("UPDATE users SET `balance` = `balance` + %s WHERE chat_id = %s",
                                   (int(summa), chat_id))

        return updated

    async def getWithdraws(self):
        raw = await self.get("""SELECT sum(money) as money FROM withdraws""")
        return raw.get("money", 0)

    async def insert_withdraws(self, money):
        await self.apply("INSERT INTO withdraws(money) VALUES(%s)", (money))

    async def referallMoney(self):
        return (await self.get("""SELECT SUM(u.referalls) * p.referall AS referall_money 
FROM users u, panel p 
GROUP BY p.referall""")).get("referall_money", 0)

    # get all withdraws as sum
    async def allSumma(self):
        referall = await self.getReferallMoney()
        withdraws = await self.getWithdraws()
        users = await self.get(
            "SELECT COUNT(*) as users, COUNT(is_active) as aktiv, SUM(balance) as users_balance FROM users")
        numbers = await self.get("SELECT COUNT(*) as numbers FROM numbers")
        users_balance = await self.get("SELECT SUM(balance) as users_balance FROM users")
        text = f"""Jami summa: {referall + withdraws}
Nomer summa: {withdraws}
Referall summa: {referall}
Nomer soni: {numbers.get('numbers', 0)}
Userlar: {users.get('users', 0)}
Aktiv userlar: {users.get('aktiv', 0)}

Userlarning jami balansi: {users.get('users_balance', 0)}"""
        return text

    async def change_competition(self, app_id):
        await self.apply("UPDATE panel SET `application_id` = %s", (app_id))

    async def change_minimal_money(self, money):
        await self.apply("UPDATE panel SET `minimal` = %s", (money))

    async def change_referall_money(self, money):
        await self.apply("UPDATE panel SET `referall` = %s", (money))

    async def getReferal(self, invited):
        res = await self.get("select inviter from referal where invited=%s", invited)
        return res.get('inviter', None)

    async def insertReferal(self, inviter, invited):
        await self.apply("insert into referal (inviter, invited) values (%s, %s)", (inviter, invited))

    async def removeReferal(self, inviter, invited):
        await self.apply("DELETE FROM `referal` WHERE inviter=%s and invited=%s", (inviter, invited))

    async def getPayLastMsg(self, chat_id):
        res = await self.get("select message_id from pay_messages where chat_id=%s", chat_id)
        return res.get('message_id', None)

    async def insertPayLastMsg(self, chat_id, message_id):
        await self.apply("DELETE FROM `pay_messages` WHERE chat_id=%s", (chat_id))
        inserted = await self.apply("insert into pay_messages (chat_id, message_id) values (%s, %s)",
                                    (chat_id, message_id))
        if not inserted:
            await self.updatePayLastMsg(chat_id, message_id)

    async def updatePayLastMsg(self, chat_id, message_id):
        await self.apply("update pay_messages set message_id=%s where chat_id=%s", (chat_id, message_id))
