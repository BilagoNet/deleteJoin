from aiogram.dispatcher.filters.state import State, StatesGroup


class Vote(StatesGroup):
    get_phone = State()
    get_math = State()
    get_sms = State()


class Widthdraw(StatesGroup):
    get_summa = State()
    get_number = State()
    wait_correct = State()
    

class Panel(StatesGroup):
    change_money = State()
    change_competition = State()
    change_referall = State()
    change_minimal = State()
    