import aiohttp


class PaymeAPI:
    def __init__(self, base_url, session):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
            "api-session": session,
            "track-id": "081fbdb509e5b60bbe3d6df089a1ab49871adefc9b3f7b69f962aedc8a41fc6f",
            "device": "64f0cd7132e1179f57eddb89; w4wQAWu4jm87kGJGQkQVOX#=iWf49k24VPKwW@KOmbHyPPpb#GkG4pJZ?dFo30dh;",
            'Cookie': "cookiesession1=678A3E10772DA82FE94C8E4819B278E5;"
        }

    async def get_card_info(self, card_number):
        url = f"{self.base_url}/api/cards.get_p2p_info"
        params = {"method": "cards.get_p2p_info", "params": {"number": card_number, "masked_owner": False}}
        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.post(url, json=params, headers=self.headers) as response:
                data = await response.json()
                return data

    async def create_cheque(self, card_number, amount, description, merchant_id=None):
        url = f"{self.base_url}/api/p2p.create"
        if len(card_number) == 16:
            params = {"method": "p2p.create",
                      "params": {"number": card_number, "amount": amount * 100, "description": description,
                                 "currency": 860}}
        else:
            params = {"method": "cheque.create",
                      "params": {"account": {"phone": card_number}, "amount": amount * 100,
                                 "merchant_id": merchant_id}}

        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.post(url, json=params, headers=self.headers) as response:
                data = await response.json()
                return data

    async def verify_pay(self, cheque_id):
        url = f"{self.base_url}/api/cheque.pay"
        params = {"method": "cheque.pay", "params": {"id": cheque_id, "card_id": "634b0dc9cad1c75163baa35c"}}

        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.post(url, json=params, headers=self.headers) as response:
                data = await response.json()
                return data
