from aiogram.types import InlineKeyboardMarkup as Im, InlineKeyboardButton as Ikb, KeyboardButton as Kb, \
    ReplyKeyboardMarkup as Rkm


def home():
    markup = Rkm(resize_keyboard=True)
    markup.row(Kb("Hisobim💰"), Kb("📥 Pulni yechib olish"))
    markup.row(Kb("🔗 Referal ssilka"), Kb("📝 Qo'llanma"))
    return markup


def share_keyboard(chat_id):
    keyboard = Im()
    keyboard.row(Ikb("Doʻstlarni Taklif Qilish⤴️", switch_inline_query=f"{chat_id}"))

    return keyboard


def startref(url):
    keyboard = Im()
    keyboard.row(Ikb("Boshlash✅", url=url))

    return keyboard


def withdraw_keyboard():
    keyboard = Im(row_width=2)
    keyboard.row(Ikb(text='📥 Pulni yechib olish', callback_data='withdraw'))

    return keyboard


def withdraw_correct_keyboard():
    keyboard = Im(row_width=2)
    keyboard.row(Ikb(text='✅ Tasdiqlash', callback_data='withdraw-correct'))
    keyboard.row(Ikb('❌ Bekor qilish', callback_data='withdraw-cancel'))

    return keyboard


def broadcast_keyboard():
    keyboard = Im(row_width=2)
    keyboard.row(Ikb(text='Yuborish 🚀', callback_data='send'))

    return keyboard


def correct_payment(chat_id):
    markup = Im()
    markup.row(Ikb(text="✅ To'lov qilindi", callback_data=f'correct-{chat_id}'))
    markup.row(Ikb('❌ Bekor qilish', callback_data=f'cancel-{chat_id}'))

    return markup


def main_panel():
    keyboard = Im(row_width=2)
    referall = Ikb(text="📎 Referall summasi", callback_data="change_referall")
    minimal = Ikb("📥 Minimal pul yechish", callback_data="change_withdraw")
    money = Ikb(text='💰 Pul berish summasi', callback_data='change_money')
    app_id = Ikb(text="🆔 Tanlov raqami", callback_data='change_competition')
    keyboard.row(referall, minimal)
    keyboard.row(money, app_id)

    return keyboard


def cancel_change_keyboard():
    keyboard = Im(row_width=2)
    keyboard.row(Ikb('❌ Bekor qilish', callback_data='cancel_change'))

    return keyboard
