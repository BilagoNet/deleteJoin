from typing import Union
from math import pow
from re import sub


from aiohttp import ContentTypeError, ClientResponse
from helpers.payapi.exceptions import FailedDecodeJson


async def validate_json(resp: ClientResponse, content_type: str = 'application/json') -> dict:
    try:
        return await resp.json(content_type=content_type)
    except ContentTypeError as e:
        bad_url = str(str(e).split(",")[2]).split("'")[1]
        raise FailedDecodeJson(f"Check args, URL is invalid\nURL- {bad_url}")


def moneyFormat(e: Union[int, float]) -> str:
    _math = str(e / pow(10, 2))
    money = sub(r"\B(?=(\d{3})+(?!\d))", " ", _math)
    return money
