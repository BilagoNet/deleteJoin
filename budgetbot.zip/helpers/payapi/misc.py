from re import sub, search


class ApelsinUrl:
    BALANCE = 'https://mobile.apelsin.uz/api/humo'
    Uzcard2Service = 'https://mobile.apelsin.uz/api/transaction/hold/humo2service'
    Uzcard2 = 'https://mobile.apelsin.uz/api/transaction/hold/humo2{}'

    TRANSFER = 'https://mobile.apelsin.uz/api/transaction/transfer'
    SERVICE = 'https://mobile.apelsin.uz/api/check/service'
    RECEIVERINFO = 'https://mobile.apelsin.uz/api/recipient/info?receiver={}'


class ApelsinService:
    Ucell = "545e1b1e5ae5eca82d1b4630"
    Beeline = "545c7ecd5ae5eca82d1b462f"
    UzMobile = "55478199d2c4830936e6c832"
    MobiUz = "549981c05ae5eca82d1b4661"
    Perfectum = "545e1cae5ae5eca82d1b4631"


class PhoneCode:
    CODES = {"99": ApelsinService.UzMobile, "95": ApelsinService.UzMobile, "93": ApelsinService.Ucell, "94": ApelsinService.Ucell,
             "90": ApelsinService.Beeline, "91": ApelsinService.Beeline, "97": ApelsinService.MobiUz,
             "88": ApelsinService.MobiUz, "98": ApelsinService.Perfectum}


class CheckService:
    def __init__(self, num):
        self.serviceId = None
        self.serviceName = None
        self.number = sub(r"\s", "", num)
        self.number = search(
            r"^(?:\+|\+998|998)?((?:99|98|97|95|94|93|91|90|88)[0-9]{7})$", self.number)

    def check(self):
        if self.number and len(self.number.group(1)) == 9:
            for _key, _value in vars(ApelsinService).items():
                if _key.startswith('__'):
                    continue
                if _value == PhoneCode.CODES[self.number.group(1)[:2]]:
                    self.serviceId = _value
                    self.serviceName = _key
                    return True
        return False

    def getServiceName(self):
        return self.serviceName

    def getServiceId(self):
        return self.serviceId


class CheckReceiver:
    def __init__(self, card_number):
        self.card_number = sub(r"\s", "", card_number)

    def check(self):
        if self.card_number.isdigit() and len(self.card_number) == 16:
            regex = search(r"^[0-9]{16}$", self.card_number)
            if regex:
                return True
            else:
                return False
        return False


class Requests:
    HEADERS = {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "app-version": "w0.0.1",
        "content-type": "application/json;charset=UTF-8",
        "device-id": "e09e4b14c269ef9e1bc7480f5f1671a3",
        "lang": "uz",
        "origin": "https://apelsin.uz",
        "referer": "https://apelsin.uz/",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "Windows",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "token": "5a9f721f-97fd-4fa2-b0f1-f702085d595b",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36",
    }
