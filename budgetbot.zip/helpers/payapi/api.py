from math import pow
from re import sub

from helpers.payapi.client import HTTPClient
from helpers.payapi.misc import ApelsinUrl, Requests, CheckService, CheckReceiver

from helpers.payme.api import PaymeAPI


class Apelsin(HTTPClient):
    def __init__(self, device_id, token, Db):
        self.token = token
        self.device_id = device_id
        self.Db = Db

        Requests.HEADERS['token'] = self.token
        Requests.HEADERS['device-id'] = self.device_id

    def get_token(self):
        return self.token

    def get_device_id(self):
        return self.device_id

    async def get_balance(self):
        url = ApelsinUrl.BALANCE
        response = await self.request(
            'GET',
            url,
            headers=Requests.HEADERS
        )
        data = response.get("data")[0]
        balance_core = int(data.get("balance"))
        balance = format(balance_core / pow(10, 2), ".2f")
        balance = sub("\B(?=(\d{3})+(?!\d))", " ", str(balance))
        return balance + " UZS"

    async def sendservice(self, _fieldValueList, _serviceId):
        fieldValueList = {"fieldValueList": _fieldValueList, "serviceId": _serviceId}

        url = ApelsinUrl.SERVICE
        response = await self.request(
            'PUT',
            url,
            headers=Requests.HEADERS, json=fieldValueList
        )

        data = response.get("data")
        errorMessage = response.get("errorMessage")
        if errorMessage != "": return "Xatolik: " + errorMessage

        if len(data) == 3:
            return data[-1].get("value")
        else:
            return ""

    async def paytophone(self, amount, phone_number):
        service = CheckService(phone_number)
        check_service = service.check()

        get_payme_token = await self.Db.get('select * from panel')
        payme_token = get_payme_token.get('payme_session')
        payme = PaymeAPI("https://payme.uz", payme_token)

        cheque = await payme.create_cheque(phone_number, amount, "@OpenBudjetBot", service.getServiceId())
        if cheque.get("error", False):
            return cheque.get("error").get("message")
        else:
            cheque_id = cheque.get('result').get("cheque").get("_id")
            pay = await payme.verify_pay(cheque_id)
            if pay.get("error", False):
                return pay.get("error").get("message")
            else:
                return "Muvaffaqiyatli"
        if check_service:
            # fieldAlias list = ['clientid', 'phone_number'. 'MSISDN']
            if service.serviceId in [999278, 974865]:
                fieldAlias = 'clientid'
            elif service.serviceId in [974769, 64]:
                fieldAlias = 'phone_number'
            else:
                fieldAlias = 'MSISDN'

            fieldValueList = [{"fieldAlias": fieldAlias, "value": service.number.group(1)}]

            get_identity = await self.sendservice(fieldValueList, service.serviceId)
            if get_identity.isdigit() or get_identity == "":
                data = {"amount": amount * 100, "cardId": "2872532", "currency": {"name": "UZS", "scale": 2},
                        'fieldValueList': fieldValueList, "reserveSms": "false",
                        "identity": get_identity, "senderFullName": "Ilhomboyota",
                        "serviceId": service.serviceId, "smsCode": "", "fixedAmount": "false"}

                Uzcard2Service = ApelsinUrl.Uzcard2Service

                operationHold = await self.request(
                    'POST',
                    Uzcard2Service,
                    headers=Requests.HEADERS, json=data
                )

                if operationHold.get("errorMessage") == "":
                    operationHoldId = operationHold.get("data").get("operationHoldId")
                    transfer_data = {"operationHoldId": operationHoldId, "smsCode": ""}
                    transfer_status = await self.request(
                        'POST',
                        ApelsinUrl.TRANSFER,
                        headers=Requests.HEADERS, json=transfer_data
                    )

                    return transfer_status.get("data").get("message") if transfer_status.get(
                        "errorMessage") == "" else transfer_status.get("errorMessage")
                else:
                    return operationHold.get("errorMessage")
            else:
                return get_identity
        else:
            return "Phone number is not valid"

    async def cardInfo(self, card_number):
        card = CheckReceiver(card_number)
        check_card = card.check()
        if check_card:
            get_payme_token = await self.Db.get('select * from panel')
            payme_token = get_payme_token.get('payme_session')
            payme = PaymeAPI("https://payme.uz", payme_token)
            info = await payme.get_card_info(card_number)
            if info.get("result", False):
                return info.get('result').get('owner')
            else:
                return info.get('error').get('message')
        else:
            return "Card number is not valid"

    # pay to card
    async def paytocard(self, amount, card_number, receiver_name):
        card_number = CheckReceiver(card_number).card_number

        sendmoneypayload = {"amount": amount * 100, "currency": {"name": "UZS", "scale": 2}, "receiver": card_number,
                            "receiverFullName": receiver_name, "reserveSms": "false", "sender": "9860 19** **** 9239",
                            "senderFullName": "ILHOMJON RAHIMOV", "senderId": 5725464}
        # pay to card number with payme
        get_payme_token = await self.Db.get('select * from panel')
        payme_token = get_payme_token.get('payme_session')

        payme = PaymeAPI("https://payme.uz", payme_token)
        cheque = await payme.create_cheque(card_number, amount, "@OpenBudjetBot")
        if cheque.get("error", False):
            return cheque.get("error").get("message")
        else:
            cheque_id = cheque.get('result').get("cheque").get("_id")
            pay = await payme.verify_pay(cheque_id)
            if pay.get("error", False):
                return pay.get("error").get("message")
            else:
                return "Muvaffaqiyatli"

        uzcard2 = ApelsinUrl.Uzcard2.format("uzcard" if card_number.startswith("8600") else "humo")

        uzcard2info = await self.request("POST", uzcard2, headers=Requests.HEADERS, json=sendmoneypayload)
        if uzcard2info.get("errorMessage") == "":
            operationHoldId = uzcard2info.get("data").get("operationHoldId")
            transfer = await self.request("POST", ApelsinUrl.TRANSFER, headers=Requests.HEADERS,
                                          json={"operationHoldId": operationHoldId, "smsCode": ""})
            if transfer.get("errorMessage") == "":
                return "Muvaffaqiyatli"
            else:
                return transfer.get("errorMessage")
        else:
            return uzcard2info.get("errorMessage")
