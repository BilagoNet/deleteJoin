import aiohttp

from helpers.payapi.exceptions import BadMethod
from helpers.payapi.utils import validate_json


class HTTPClient:

    @staticmethod
    async def request(method: str, url: str, *args, **kwargs) -> dict:
        async with aiohttp.ClientSession() as session:
            if method.upper() == 'GET':
                async with session.get(url, **kwargs) as resp:
                    return await validate_json(resp, *args)
            elif method.upper() == 'POST':
                async with session.post(url, **kwargs) as resp:
                    return await validate_json(resp, *args)
            elif method.upper() == 'PUT':
                async with session.put(url, **kwargs) as resp:
                    return await validate_json(resp, *args)
            else:
                raise BadMethod('Accept only GET/POST/PUT')
