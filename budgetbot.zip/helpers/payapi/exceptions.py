class BadMethod(Exception):
    pass


class FailedDecodeJson(Exception):
    pass
