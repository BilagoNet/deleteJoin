from re import sub

number = "902215323"
num = sub("(?:\+|\+998|998)?((?:99|98|97|95|94|93|91|90)[0-9]{7})", "\1", number)

print(num)
