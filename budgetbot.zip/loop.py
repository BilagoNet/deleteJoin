from time import sleep

from tqdm import tqdm

from random import randint


for i in tqdm(range(900000000)):
    pass
