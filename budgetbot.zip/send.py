from asyncio import sleep, run, get_event_loop

import aiomysql

from aiogram.utils.exceptions import RetryAfter

from tqdm import tqdm

from loader import dp

from helpers.config import BOT_USERNAME


loop = get_event_loop()


async def _send():
    text = """*SUPER YANGILIK ENDI BOT XAR BIR OVOZ UCHUN 4000va 3000referal uchun 7000ming SOMDAN TOLAYDI GAZINI BOSILA🤑🤑🤑🤑 

Aziz foydalanuvchi siz oʻz ovozingizni berish orqali botdan 7000so'm paynet sohibi boʼlishiz mumkin.
Unutmang sizning ovozingiz bizning mahallamiz obodonlashtirish uchun juda muhim

/start /start /start*"""
    conn = await aiomysql.connect(host='localhost', port=3306,
                                       user='RakhimovUzb', password='Ilhom1909', db=BOT_USERNAME,
                                       loop=loop)
    
    cur = await conn.cursor()
    await cur.execute("SELECT chat_id FROM `users`")
    r = await cur.fetchall()
    await cur.close()
    conn.close()

    success, error = 0, 0
    for chat in tqdm(r, desc="🔃 Yuborilmoqda"):
        chat = chat[0]
        try:
            await dp.bot.send_message(chat, text=text, parse_mode='markdown', disable_web_page_preview=True)
            success += 1
        except RetryAfter as e:
            print("Wait:", e.timeout)
            await sleep(e.timeout)
            try:
                await dp.bot.send_message(chat, text=text, parse_mode='markdown', disable_web_page_preview=True)
                success += 1
            except:
                error += 1
        except:
            error += 1
    print(f"✅ Yuborildi: {success}\n❌ Yuborilmadi: {error}")
    await dp.storage.close()
    await dp.storage.wait_closed()
    session = await dp.bot.get_session()
    await session.close()

try:
    run(_send())
except KeyboardInterrupt:
    pass
