# from aiogram.contrib.fsm_storage.redis import RedisStorage2
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from aiogram import Dispatcher, Bot

from helpers.database import MySQLStorage

from helpers.config import BO_TOKEN, BOT_USERNAME
from helpers.payapi.api import Apelsin

bot = Bot(BO_TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

Database: MySQLStorage = MySQLStorage(BOT_USERNAME, user='root', password='oyatillo99')

apelsin = Apelsin("e09e4b14c269ef9e1bc7480f5f1671a3", "eeed4fe3-67e1-4c06-85be-4adc25e265a6", Db=Database)
validate_url = "https://openbudget.uz/api/v2/vote/mvc/captcha"
vote_url = "https://openbudget.uz/api/v2/vote/mvc/verify"


headers = {
        'Origin': 'https://openbudget.uz',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
        'Cookie': 'ADRUM_BT1=R:91|i:7753|e:68; ADRUM_BTa=R:91|g:7a67198f-736c-4e57-baae-341894f3bf48|n:customer1_9c28b63e-99cb-4969-b91e-d0d7809dc215; OB-SESSION=64edddef629dcf60c8cead49; SameSite=None; route=f1d639df3365f84857f1ac304886ad41'
        }

regex_num = r"^(?:\+998|998)?([9][01345789][0-9]{7}|3[3][0-9]{7}|8[8][0-9]{7}|7[7][0-9]{7})$"
regex_new_number = r"^(?:\+998|998)?(\d{0,2})(\d{0,3})(\d{0,2})(\d{0,2})"
