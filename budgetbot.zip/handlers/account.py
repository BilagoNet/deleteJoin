from contextlib import suppress
from uuid import uuid4
import re

from aiogram.types import CallbackQuery, InlineQuery, InlineQueryResultCachedPhoto, Message
from aiogram.dispatcher import FSMContext
from aiogram.utils.exceptions import Throttled

from helpers.keyboards import withdraw_keyboard, withdraw_correct_keyboard, share_keyboard, startref, correct_payment
from helpers.states import Widthdraw, Vote
from helpers.payapi.misc import CheckService

from helpers.config import BOT_USERNAME, CHANNEL

from loader import dp, Database as Db, apelsin




@dp.message_handler(content_types='photo', chat_type='private', state='*')
async def fli(message):
    await message.reply(message.photo[-1].file_id)


@dp.message_handler(text=["Hisobim💰", '/balance'], state='*', chat_type="private")
async def get_money(message, state: FSMContext):
    stat = await state.get_state()
    if stat is not None:
        await state.finish()
    user_balance = await Db.getBalance(message.from_user.id)
    await message.answer(f"Sizning hisobingiz: {user_balance}", parse_mode="markdown", reply_markup=withdraw_keyboard())


@dp.message_handler(text="🔗 Referal ssilka", state="*")
async def _mylink(message, state: FSMContext):
    # if state is not None finish it
    stat = await state.get_state()
    if stat is not None:
        await state.finish()

    ssilka = f"https://t.me/ochiqbudgetbot?start={message.from_user.id}"
    await message.answer_photo("AgACAgIAAxkBAAEBAtJk8KyW6iKlfhsnkaMXP5Wmn-n2nAACoM0xG8TNiUtfjrcweDd3ywEAAwIAA3gAAzAE",
                               caption=f"Sizning referal ssilkangiz!\n\n{ssilka}",
                               reply_markup=share_keyboard(message.from_user.id))


@dp.inline_handler(state="*")
async def _myref(query: InlineQuery):
    if query.chat_type == "private":
        ssilka = f"https://t.me/ochiqbudgetbot?start={query.from_user.id}"
    else:
        ssilka = f"https://t.me/ochiqbudgetbot?start={query.query}"

    sum = await Db.getMoney()

    results = [
        InlineQueryResultCachedPhoto(
            id=str(uuid4()),
            title="Yuborish 🚀",
            photo_file_id="AgACAgIAAxkBAAEBAtJk8KyW6iKlfhsnkaMXP5Wmn-n2nAACoM0xG8TNiUtfjrcweDd3ywEAAwIAA3gAAzAE",
            caption=f"""*Telegramda turib pul ishlashni hoxlasaysizmi?*

__[@ochiqbudgetbot]({ssilka})' ga kiring va roʻyxatdan oʻtish uchun telefon raqamizni kiriting! Xar bir roʻyxatdan oʻtkazgan nomeriz uchun {sum}soʻm dan pul mukofoti beriladi!__

*Botdagi hisobizdan pulni bank karta raqamizga(Humo/Uzcard) yechib olishingiz yoki paynet orqali yechib olishingiz mumkin, Toʻlovlar 5sekund ichida amalga oshiriladi*

*{ssilka}*""",
            parse_mode="markdown", reply_markup=startref(ssilka))
    ]

    await query.answer(results)


@dp.message_handler(text=["📥 Pulni yechib olish", "/withdraw"], state='*', chat_type="private")
async def withdraw_money(message, state: FSMContext):
    stat = await state.get_state()
    if stat is not None:
        await state.finish()
    user_balance = await Db.getBalance(message.from_user.id)
    minimal_money = await Db.getMinimalMoney()
    if user_balance is None:
        print("user_balance none", message.from_user.id)
        await message.answer("Xatolik bor: /start yuboring")
        return
    if minimal_money is None:
        print("minimal money none", message.from_user.id)
        await message.answer("Xatolik bor: /start yuboring")
        return
    
    if int(user_balance) < int(minimal_money):
        await message.answer(
            f"Pul yechib olish uchun hisobingizda {minimal_money}so'mdan kop pul bo'lishi shart!\n\nHozirgi balansngiz: {user_balance}so'm",
            parse_mode="html")
    else:
        await message.answer("*Qancha summa yechib olmoqchisiz?*\n__Namuna:__ *10000*", parse_mode="markdown")
        await Widthdraw.get_summa.set()


@dp.callback_query_handler(text="withdraw")
async def withdraw(call: CallbackQuery):
    user_balance = await Db.getBalance(call.from_user.id)
    minimal_money = await Db.getMinimalMoney()
    if user_balance is None:
        print("user_balance none", call.from_user.id)
        await call.message.answer("Xatolik bor: /start yuboring")
        return
    
    if minimal_money is None:
        print("minimal money none", call.from_user.id)
        await call.message.answer("Xatolik bor: /start yuboring")
        return
    
    if int(user_balance) < int(minimal_money):
        await call.answer(f"Pul yechib olish uchun hisobingizda {minimal_money}so'mdan koʻp pul bo'lishi shart!",
                          show_alert=True)
    else:
        try:
            await call.message.edit_text("*Qancha summa yechib olmoqchisiz?*\n__Namuna:__ *10000*",
                                         parse_mode="markdown")
        except:
            pass
        await Widthdraw.get_summa.set()


@dp.message_handler(state=Widthdraw.get_summa)
async def get_summa(message, state: FSMContext):
    if message.content_type == 'text' and message.text.isdigit():
        minimal_money = await Db.getMinimalMoney()
        user_balance = await Db.getBalance(message.from_user.id)
        if int(user_balance) < int(message.text):
            await message.answer("*Hisobingizda buncha pul yo'q, qayta yuboring!*\n\nBekor qilish: /start",
                                 parse_mode="markdown")
            return
        elif int(message.text) < int(minimal_money):
            await message.answer(
                f"*Minimal pul yechib olish {minimal_money}so'm!\nQayta yuboring*\n\nBekor qilish: /start",
                parse_mode="markdown")
            return

        async with state.proxy() as data:
            data['summa'] = message.text

        await message.answer(
            "*Pulni yechib olish uchun telefon yoki karta raqamingizni kiriting:*\nEslatma: Yuborishdan avval yaxshilab tekshiring!\n*Pulingizni Humans va viza kartalarga yechmang*!",
            parse_mode="markdown")

        await Widthdraw.next()
    else:
        await message.answer("*Summani faqat raqam ko'rinishida qayta yuboring!*", parse_mode="markdown")


@dp.message_handler(state=Widthdraw.get_number)
async def get_number(message: Message, state: FSMContext):
    msg_id = await Db.getPayLastMsg(message.from_user.id)
    if msg_id:
        with suppress(Exception):
            await message.bot.delete_message(message.from_user.id, int(msg_id))
    if message.content_type == 'text':
        if len(message.text.replace(" ", "")) == 16:
            card_info = await apelsin.cardInfo(message.text)
            if card_info in ["Card number is not valid", 'visa', "Karta raqami noto'g'ri"]:
                await message.answer("*Karta raqami xato yuborildi, qayta yuboring!*\n\nBekor qilish: /start",
                                     parse_mode='markdown')
            elif card_info.startswith("Xatolik"):
                await message.answer(
                    "*Karta haqida ma'lumot olib bo'lmadi, boshqa karta yuboring!*\n__" + card_info + "__\n\nBekor qilish: /start",
                    parse_mode='markdown')
            else:
                async with state.proxy() as data:
                    data["number"] = message.text
                    number = message.text
                    summa = data['summa']
                    data['receiver_name'] = card_info
                    data['paytype'] = 'card'

                msg = await message.answer(
                    f"*Tasdiqlang:*\n__Raqam:__ {number}\n__Qabul qiluvchi:__ {card_info}\n__Summa:__ {summa}",
                    parse_mode="markdown",
                    reply_markup=withdraw_correct_keyboard())
                await Db.insertPayLastMsg(message.from_user.id, msg.message_id)
                await Widthdraw.next()
        else:
            service = CheckService(message.text)
            check_service = service.check()
            if check_service:
                async with state.proxy() as data:
                    summa = data['summa']

                    data['number'] = message.text
                    data['service'] = service.getServiceName()
                    data['paytype'] = 'phone'

                msg = await message.answer(
                    f"*Tasdiqlang:*\n__Raqam:__ {message.text}\n__Operator:__ {service.getServiceName()}\n__Summa:__ {summa}",
                    parse_mode="markdown",
                    reply_markup=withdraw_correct_keyboard())
                await Db.insertPayLastMsg(message.from_user.id, msg.message_id)
                await Widthdraw.next()
            else:
                await message.answer("*Raqamni tekshirib qayta yuboring!*", parse_mode="markdown")
    else:
        await message.answer("*Raqamni faqat matn ko'rinishida qayta yuboring!*\n\nBekor qilish: /start",
                             parse_mode="markdown")


@dp.callback_query_handler(state=Widthdraw.wait_correct)
async def wait_correct(call: CallbackQuery, state: FSMContext):
    try:
        await call.message.edit_reply_markup()
    except:
        await state.finish()
        return
    try:
        await dp.throttle('waitpay', rate=3)
    except Throttled:
        await call.message.answer("*Flood qilma iplos😡\nPulindan ayrilasan!*", parse_mode="markdown")
    else:
        if call.data == "withdraw-correct":
            await call.answer("To'lov amalga oshirilmoqda...", show_alert=True)

            async with state.proxy() as data:
                paytype = data['paytype']
                number = data["number"]
                summa = data["summa"]
                info = data['receiver_name'] if paytype == 'card' else data['service']

                minimal_money = await Db.getMinimalMoney()
                user_balance = await Db.getBalance(call.from_user.id)
                try:
                    if int(user_balance) < int(minimal_money):
                        await call.message.edit_text("*Nimadur xato*\n\n/start bosing", parse_mode='markdown')
                        await state.finish()
                        return
                except Exception:
                    await call.message.edit_text("*Nimadur xato*\n\n/start bosing", parse_mode='markdown')
                    await state.finish()
                    return

                await state.finish()

                if paytype == 'card':
                    await Db.downBalance(call.from_user.id, summa)
                    with suppress(Exception):
                        await call.message.delete()

                    text = f"""💰Платежный запрос
💳 `{number}`
🗂 {info}
💰 Summa: {summa} so'm"""
                    user_text = """\n\n✅ Pulni yechib olish boʻyicha soʻrovingiz maʼqullandi.
Iltimos,hisobingizni 10-20 daqiqa ichida tekshiring, to'lov amalga oshiriladi."""
                    with suppress(Exception):
                        await dp.bot.send_message(CHANNEL, text, reply_markup=correct_payment(call.from_user.id), parse_mode='markdown')
                    await call.message.answer(text + user_text)
                    await Vote.get_phone.set()
                    return
                else:
                    payinfo = await apelsin.paytophone(int(summa), number)
            try:
                md_text = call.message.md_text.replace('\\', '', 1)
                text = md_text.replace("*Tasdiqlang:*", "")
                await call.message.edit_text(text + f"\n\nHolat: {payinfo}", parse_mode="markdown")
            except:
                pass
            if payinfo == 'Muvaffaqiyatli':
                await Db.downBalance(call.from_user.id, summa)
                await Db.insert_withdraws(summa)
                with suppress(Exception):
                    tekst = re.sub(r"(?:\+998|998)?(\d{2})(\d+)(\d{4})", r"\1***\3", text)
                    await dp.bot.send_message(CHANNEL, tekst)

            else:
                await call.message.answer("Kartaga yechib oling!")
        else:
            await call.message.edit_text("*❌ Bekor qilindi!*", parse_mode="markdown")
        await state.finish()
