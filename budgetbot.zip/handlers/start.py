from contextlib import suppress

from aiogram.dispatcher import FSMContext
from aiogram.types import Message

from loader import dp, Database as Db
from helpers.states import Vote
from helpers.keyboards import home
from helpers.config import ADMINS


@dp.message_handler(content_types='video', state="*", user_id=ADMINS)
async def getPhotoId(message: Message):
    print(message.from_user.id, message.message_id)


@dp.message_handler(text_startswith=['/start'], chat_type='private', state="*")
async def start(message: Message, state: FSMContext):

    # if state is not None finish it
    stat = await state.get_state()
    if stat is not None:
        await state.finish()
    user_mention = message.from_user.get_mention(message.from_user.first_name, False)
    await message.answer(f"""👋Assalomu alaykum hurmatli {user_mention}""",
                        parse_mode="markdown", reply_markup=home())

    sum = await Db.getMoney()

    await message.answer(f"""*Aziz foydalanuvchi siz oʻz ovozingizni berish orqali botdan {sum}so'm paynet sohibi boʼlishiz mumkin.
Unutmang sizning ovozingiz bizning mahallamiz obodonlashtirish uchun juda muhim*""", parse_mode="markdown")

    await message.answer("""*🚀 Botdan foydalanish uchun telefon raqamingizni kiritishingiz kerak.
* `901234567` *shaklida raqamingizni kiriting*""", parse_mode="markdown", reply_markup=home())

    await Vote.get_phone.set()

    try:
        inserted = await Db.insert_user(message.from_user.id)
        if inserted:
            chat_id = message.get_args()
            if chat_id.isdigit() and int(chat_id) != message.from_user.id:
                user_exist = await Db.exist_user(chat_id)
                if user_exist:
                    await Db.insertReferal(chat_id, message.from_user.id)
                    name = message.from_user.get_mention(message.from_user.first_name, as_html=True)
                    referall_money = await Db.getReferallMoney()
                    await dp.bot.send_message(chat_id, f"<b>Sizning referalingiz orqali {name} tashrif buyurdi. Ro'yxatdan o'tsa sizning hisobizga {referall_money}so'm tushadi</b>", parse_mode="HTML")
    except Exception:
        pass
  
