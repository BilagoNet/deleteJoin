import io
import base64
import uuid

from contextlib import suppress
from re import search

from aiogram.dispatcher import FSMContext
from aiogram.types import Message, InputFile
from aiogram.utils.exceptions import Throttled

from playwright.async_api._generated import BrowserContext, Page
from playwright.async_api._generated import Playwright as AsyncPlaywright
from helpers.proxy import get_proxy

from helpers.states import Vote
from helpers.keyboards import home

from loader import dp, regex_num, Database as Db


browsers = {}


@dp.message_handler(state=Vote.get_phone, chat_type='private')
async def get_phone(message: Message, state: FSMContext):
    if message.from_id in browsers:
        await browsers[message.from_id].close()
        del browsers[message.from_id]

    phone = search(regex_num, message.text)
    if phone is None or not str(phone.group(1).startswith('77')):
        await message.answer("❗ Raqam no'to'gri kiritildi!\nNamuna: +998991234567\n\nBekor qilish: /start")
        return
    elif str(phone.group(1)).startswith("33"):
        await message.answer("❗ Ovoz berish jarayonida HUMANS mobil operatorlaridan foydalnishga ruxsat etilmaydi!\n\nBekor qilish: /start")
        return
    try:
        await dp.throttle('start', rate=2)
    except Throttled:
        await message.delete()
        return

    check_number = await Db.check_number("998" + str(phone.group(1)))
    if check_number:
        await message.reply("Ovoz berish jarayonida bu raqamdan foydalanilgan!\nBoshqa raqam yuboring:\n\nBekor qilish: /start")
        return
        
    msg = await message.answer("🔃 Kuting...")
    browser: AsyncPlaywright = dp.bot['browser']

    uuid_code = uuid.uuid4()
    # proxy = await get_proxy()
    browser: BrowserContext = await browser.chromium.launch_persistent_context(
        headless=True,
        # proxy={
        #        'server': proxy,
        #        },
        executable_path='C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        user_data_dir=f'C:\\Users\\user\\Desktop\\budgetbot\\users\\{message.from_id}-{uuid_code}',
        args=[
            f'--profile-directory="Profil {message.from_user.first_name}-{uuid_code}"'
        ]
    )
    page: Page = await browser.new_page()

    app_id = await Db.getApplicationId()
    await page.goto(f"https://openbudget.uz/boards/initiatives/initiative/31/{app_id}")

    browsers[message.from_id] = browser

    await page.wait_for_selector(".vote")

    await page.evaluate("""{{
            var vote = document.getElementsByClassName('vote');
            vote[1].click()
            }}""")
    
    iframe_selector = f'iframe[src="https://openbudget.uz/api/v2/vote/mvc/captcha/{app_id}"]'
    await page.wait_for_selector(iframe_selector)
    iframe_element = await page.query_selector(iframe_selector)
    iframe = await iframe_element.content_frame()

    await iframe.wait_for_selector("[name='phoneNumber']")
    phone_number = await iframe.query_selector("[name='phoneNumber']")
    num = str(phone.group(1))
    for number in num:
        await phone_number.type(number.strip())

    await iframe.wait_for_selector('.captcha-image')
    image = await iframe.query_selector('.captcha-image')
    img_src = await image.get_property('src')
    img_src_value = await img_src.json_value()
    base64_image_string = str(img_src_value).replace('data:image/png;base64,', '')

    # base64_image_string = base64_image_string[:100] + base64_image_string[132:]
    image_bytes = io.BytesIO(base64.b64decode(base64_image_string))

    with suppress(Exception):
        await msg.delete()

    await message.answer_photo(
            InputFile(image_bytes),
            caption="🤖 Xavfsizlik uchun yuqoridagi rasmdagi misolni javobini yuobring:\n\nBekor qilish: /start"
        )
    async with state.proxy() as data:
        data["phone"] = phone.string

        await Vote.next()


@dp.message_handler(state=Vote.get_math, content_types=['text'], regexp=r'^\d+$')
async def get_math(message: Message, state: FSMContext):
    try:
        await dp.throttle('start', rate=2)
    except Throttled:
        await message.delete()
        return
    
    msg = await message.answer("🔃 Kuting...")
    captcha_text = message.text.strip()
    browser: BrowserContext = browsers[message.from_id]

    pages = browser.pages
    page: Page = pages[-1]

    app_id = await Db.getApplicationId()
    try:
        iframe_selector = f'iframe[src="https://openbudget.uz/api/v2/vote/mvc/captcha/{app_id}"]'
        iframe_element = await page.query_selector(iframe_selector)
        if not iframe_element:
            raise Exception('error')
    except:
        await message.answer("Qayta /start bosing!")
        await state.finish()
        await Vote.get_phone.set()
        return
    iframe = await iframe_element.content_frame()
    try:
        captcha_input = await iframe.query_selector("#captcha")
        await captcha_input.type(captcha_text)

        submit_button = await iframe.query_selector('.submit-button')
        await submit_button.click()

        iframe_element = await page.query_selector(iframe_selector)
        iframe = await iframe_element.content_frame()
        try:
            await iframe.wait_for_selector("[name='otpCode']", timeout=5000)
            error = False
        except Exception:
            error = True
        if error:
            error_text = await iframe.evaluate(
                '''() => {{
                var text = document.getElementById('error-alert');
                return text.textContent;
        }}''',
            )
            with suppress(Exception):
                await msg.delete()
            await message.answer(error_text)
            await state.finish()
            await Vote.get_phone.set()
        else:
            with suppress(Exception):
                await msg.delete()
            await message.answer("📲 Sms kodni yuboring:\n\nBekor qilish: /start")
            await Vote.next()
    except Exception as e:
        print(e.__class__, "160")
        await message.answer("❌ Raqamga kod jo'natib bo'lmadi, qayta yuboring:\n\nBekor qilish: /start")
        await state.finish()
        await Vote.get_phone.set()
        return
    

@dp.message_handler(state=Vote.get_sms)
async def get_sms(message: Message, state: FSMContext):
    browser: BrowserContext = browsers[message.from_id]
    page: list[Page] = browser.pages
    page: Page = page[-1]

    async with state.proxy() as data:
        phone = data['phone']

    if message.content_type == 'text' and len(message.text) == 6 and str(message.text).isdigit():
        try:
            await dp.throttle('start', rate=3)
        except Throttled:
            await message.delete()
            return

        msg = await message.answer("🔃 Kuting...")

        app_id = await Db.getApplicationId()

        iframe_selector = f'iframe[src="https://openbudget.uz/api/v2/vote/mvc/captcha/{app_id}"]'
        try:
            iframe_element = await page.query_selector(iframe_selector)
            iframe = await iframe_element.content_frame()
        except:
            await message.answer("Qayta /start bosing!")
            await state.finish()
            await Vote.get_phone.set()
            return

        confirm_code = await iframe.query_selector('#confirm-code')
        sms_code = message.text.strip()
        for code in sms_code:
            await confirm_code.type(str(code))
        submit_button = await iframe.query_selector('.submit-button')
        await submit_button.click()

        try:
            await iframe.wait_for_selector('.success', timeout=5000)
            insert = await Db.insert_number(message.from_user.id, phone)
            if not insert:
                await message.answer("❌ Ovoz berish jarayonida bu raqamdan foydalanilgan, boshqa raqamni kiriting:\n\nBekor qilish: /start")
                await state.finish()
                await Vote.get_phone.set()
                return
            referall = await Db.getReferal(message.from_user.id)
            upMoney = await Db.upBalance(message.from_user.id)
            with suppress(Exception):
                await msg.delete()
            await browser.close()
            del browsers[message.from_id]
            await message.answer(f"🎉 Ovoz muvoffaqiyatli qabul qilindi va sizga {upMoney}so'm balansingizga qo'shildi!", reply_markup=home())

            if referall is not None:
                referall_money = await Db.getReferallMoney()
                await Db.upBonus(referall)
                await Db.removeReferal(referall, message.from_user.id)
                await dp.bot.send_message(referall, f"*Sizga {referall_money}so'm referal puli berildi*",
                                          parse_mode="markdown")
        except Exception:
            error_text = await iframe.evaluate(
                '''() => {{
                var text = document.getElementById('error-alert');
                return text.textContent;
        }}''',
            )
            with suppress(Exception):
                await browser.close()

            del browsers[message.from_id]
            with suppress(Exception):
                await msg.delete()
            if error_text:
                await message.answer(error_text)
                print(error_text)
            else:
                try:
                    await iframe.wait_for_selector('.success', timeout=5000)
                    insert = await Db.insert_number(message.from_user.id, phone)
                    if not insert:
                        await message.answer("❌ Ovoz berish jarayonida bu raqamdan foydalanilgan, boshqa raqamni kiriting:\n\nBekor qilish: /start")
                        await state.finish()
                        await Vote.get_phone.set()
                        return
                    referall = await Db.getReferal(message.from_user.id)
                    upMoney = await Db.upBalance(message.from_user.id)
                    with suppress(Exception):
                        await msg.delete()
                    await browser.close()
                    del browsers[message.from_id]
                    await message.answer(f"🎉 Ovoz muvoffaqiyatli qabul qilindi va sizga {upMoney}so'm balansingizga qo'shildi!", reply_markup=home())

                    if referall is not None:
                        referall_money = await Db.getReferallMoney()
                        await Db.upBonus(referall)
                        await Db.removeReferal(referall, message.from_user.id)
                        await dp.bot.send_message(referall, f"*Sizga {referall_money}so'm referal puli berildi*",
                                                parse_mode="markdown")
                except:
                    await message.answer("Qandaydur xatolik bo'ldi, raqamingizni qayta yuboring!")

        await state.finish()
        await Vote.get_phone.set()
        return
    else:
        with suppress(Exception):
            await browser.close()
        del browsers[message.from_id]


        await message.answer("Xato kiritdingiz!")
        await state.finish()
