import traceback
import sys

from aiogram.utils.exceptions import BotBlocked

from loader import dp



@dp.errors_handler()
async def errors_handler(update, error):
    # file sys.stderr
    if isinstance(error, BotBlocked):
        return True
    print(traceback.print_exc(limit=5))
    print(update, "\n")
    return True