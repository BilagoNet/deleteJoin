from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from loader import dp, Database as Db

from helpers.config import ADMINS
from helpers.keyboards import main_panel, cancel_change_keyboard
from helpers.states import Panel


@dp.message_handler(commands='panel', chat_type='private', state="*", user_id=ADMINS)
async def _main_panel(message, state: FSMContext):
    await message.answer("*Admin panel*\n\nNimani o'zgartirish kerak:", parse_mode="markdown", reply_markup=main_panel())
    try: await state.finish()
    except: pass



@dp.callback_query_handler(text='cancel_change', state="*")
async def _cancel_change(call, state: FSMContext):
    await call.message.edit_text("O'zgartirish bekor qilindi!", reply_markup=main_panel())
    try: await state.finish()
    except: pass


@dp.callback_query_handler(text_startswith='change_')
async def _change_y(call):
    change_type = call.data.replace("change_", "")
    if change_type == "money":
        current_money = await Db.getMoney()
        await call.message.edit_text(f"Tanlovda tasdiqlangandan so'ng userga beriladigan summa!\nHozirgi summa: {current_money}so'm\n\nYangi summani raqamlarda yuboring:", reply_markup=cancel_change_keyboard())
        await Panel.change_money.set()
    elif change_type == "competition":
        current_competition = await Db.getApplicationId()
        await call.message.edit_text(f"Tanlov ID raqami, bu tanlov linkidagi oxirgi raqamlardir!\nHozirgi ID: {current_competition}\n\nYangi IDni raqamlarda yuboring:", reply_markup=cancel_change_keyboard())
        await Panel.change_competition.set()

    elif change_type == "referall":
        current_referall_money = await Db.getReferallMoney()
        await call.message.edit_text(f"User referall chaqirganda beriladigan summa!\nHozirgi Summa: {current_referall_money}\n\nYangi Summani raqamlarda yuboring:", reply_markup=cancel_change_keyboard())
        await Panel.change_referall.set()
    else:
        current_minimal_money = await Db.getMinimalMoney()
        await call.message.edit_text(f"User minimal pul yechib olish summasi!\nHozirgi Summa: {current_minimal_money}\n\nYangi Summani raqamlarda yuboring:", reply_markup=cancel_change_keyboard())
        await Panel.change_minimal.set()



@dp.message_handler(state=Panel.change_money)
async def _get_change_money(message, state: FSMContext):
    if message.text and str(message.text).isdigit():
        await Db.change_money(message.text)
        await message.answer("*Yangi summaga o'zgartirildi!*", parse_mode="markdown")
        await state.finish()
    else:
        await message.answer("*Xatolik!*\nYangi summa raqamlarda qayta yuboring:", reply_markup=cancel_change_keyboard())

    

@dp.message_handler(state=Panel.change_competition)
async def _get_change_competition(message, state: FSMContext):
    await Db.change_competition(message.text)
    await message.answer("*Yangi IDga o'zgartirildi!*", parse_mode="markdown")
    await state.finish()



@dp.message_handler(state=Panel.change_referall)
async def _get_change_referall_money(message, state: FSMContext):
    if message.text and str(message.text).isdigit():
        await Db.change_referall_money(message.text)
        await message.answer("*Yangi referall summaga o'zgartirildi!*", parse_mode="markdown")
        await state.finish()
    else:
        await message.answer("*Xatolik!*\nYangi summa raqamlarda qayta yuboring:", reply_markup=cancel_change_keyboard())

    

@dp.message_handler(state=Panel.change_minimal)
async def _get_change_minimal(message, state: FSMContext):
    if message.text and message.text.isdigit():
        await Db.change_minimal_money(message.text)
        await message.answer("*Yangi minimal summaga o'zgartirildi!*", parse_mode="markdown")
        await state.finish()
    else:
        await message.answer("*Xatolik!*\nYangi summani raqamlarda qayta yuboring:", reply_markup=cancel_change_keyboard(), parse_mode='markdown')