from asyncio import sleep

from aiogram.types import CallbackQuery
from aiogram.utils.exceptions import RetryAfter

from loader import dp, Database as Db


@dp.callback_query_handler(text='send', state="*")
async def _send(query: CallbackQuery):
    wait_send = await query.message.edit_text("🔃 Yuborilmoqda...")

    message = query.message.reply_to_message
    chats = await Db.get_users()

    success, error = 0, 0
    async for chat in chats:
        try:
            await message.copy_to(chat['chat_id'], reply_markup=message.reply_markup)
            success += 1
        except RetryAfter as e:
            await sleep(e.timeout)
            try:
                await message.copy_to(chat['chat_id'], reply_markup=message.reply_markup)
                success += 1
            except:
                error += 1
        except:
            error += 1
        finally:
            await sleep(0.4)
    await wait_send.edit_text(f"✅ Yuborildi: {success}\n❌ Yuborilmadi: {error}")
