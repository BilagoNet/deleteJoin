from contextlib import suppress

from aiogram.types import Message, CallbackQuery

from loader import dp, Database as Db, apelsin

from helpers.keyboards import broadcast_keyboard
from helpers.config import ADMINS


@dp.message_handler(commands='static', user_id=ADMINS, state="*")
async def _all_statistica(message: Message):
    text = await Db.static()
    # balance = await apelsin.get_balance()
    # text += f"\n\nKartada qoldi: {balance}"
    await message.answer(text)


@dp.message_handler(commands='stat', user_id=ADMINS, state="*")
async def _all_statistica(message: Message):
    text = await Db.statistica()
    print("Kelldi")
    # balance = await apelsin.get_balance()
    # text += f"\n\nKartada qoldi: {balance}"
    await message.answer(text)


@dp.message_handler(commands='send', is_reply=True, user_id=ADMINS, state="*")
async def _broadcast(message: Message):
    await message.reply_to_message.reply("Yuborishni tasdiqlang:", reply_markup=broadcast_keyboard())


@dp.message_handler(commands='id', user_id=ADMINS, state="*")
async def getidcount(message: Message):
    app_id = message.get_args()
    count = await Db.getCountsId(app_id)
    await message.reply(f"🆔 Ushbu tanlov ID raqamiga {count}ta raqam ro'yxatgan o'tgan!")


@dp.callback_query_handler(text_startswith=['correct-', 'cancel-'], user_id=ADMINS, state='*')
async def correct_pay(call: CallbackQuery):
    click_type, chat_id = call.data.split('-')
    if click_type == 'correct':
        text = "Sizga to'lov qilindi ✅"
    else:
        text = "Sizga to'lov qilinmadi!"
    with suppress(Exception):
        await call.bot.send_message(chat_id, text)
    msg_text = call.message.text + "\n\n" + text.replace('Sizga ', '').capitalize()

    await call.message.edit_text(msg_text, reply_markup=None)
