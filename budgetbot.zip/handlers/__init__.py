from .start import dp
from .account import dp

from .admin_panel.main import dp
from .admin_panel.panel import dp
from .admin_panel.broadcast import dp
from .vote import dp

from .error_handler import dp


__all__ = ['dp']
