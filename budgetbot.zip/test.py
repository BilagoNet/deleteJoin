from asyncio import run

from playwright.async_api import async_playwright


async def main():
    playwright = async_playwright()
    browswer = await playwright.start()
    browswer = await browswer.chromium.launch(
        executable_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        args=[
            f'--user-data-dir=~/user/data/{message.from_id}-{uuid_code}',
            f'--profile-directory="{message.from_user.first_name}-{uuid_code}"'
        ]
    )
    context = await browswer.new_context()
    page = await context.new_page()
    await page.goto("https://openbudget.uz/boards/initiatives/initiative/31/03007ebe-78a8-4330-aa19-1fa643db6121")
    await playwright.stop()

run(main())