from aiogram import executor, Dispatcher
from playwright.async_api import async_playwright

from handlers import dp


async def on_start(dp):
    playwright = async_playwright()
    browswer = await playwright.start()
    dp.bot['browser'] = browswer
    dp.bot['playwright'] = playwright


async def on_shutdown(dp: Dispatcher):
    await dp.storage.close()
    await dp.storage.wait_closed()
    await dp.bot['playwright'].stop()

executor.start_polling(dp, on_shutdown=on_shutdown, on_startup=on_start, skip_updates=True)
